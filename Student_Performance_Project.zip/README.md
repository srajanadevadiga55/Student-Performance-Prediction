
# Student Performance Prediction

## Project Overview
This project uses Machine Learning to predict students' final
mathematics grades based on student-related information.

## Dataset
The project uses the Student Performance dataset.
The target variable is G3, which represents the final mathematics grade.
Previous grades G1 and G2 are excluded from the input features.

## Technologies Used
- Python
- Pandas
- NumPy
- Matplotlib
- Scikit-learn
- Google Colab

## Project Workflow
1. Load and explore the dataset.
2. Identify input features and the target variable.
3. Split the data into training and testing sets.
4. Handle numerical and categorical features.
5. Train three regression models:
   - Baseline Regression
   - Linear Regression
   - Random Forest Regression
6. Evaluate the models using MAE, RMSE, and R2 score.
7. Perform five-fold cross-validation.
8. Visualize model performance and feature importance.
9. Generate a sample prediction.

## Evaluation
The models are compared using MAE, RMSE, and R2 score.
Refer to model_evaluation_results.csv for the actual results.

## Limitations
- Predictions are estimates and may not match actual grades.
- The dataset may not represent all students or schools.
- Predictions depend on the quality and relevance of the input data.
- Feature importance indicates model usefulness, not necessarily causation.

## Future Improvements
- Test additional machine learning algorithms.
- Use a larger and more diverse dataset.
- Develop a simple web application for predictions.

## Disclaimer
This project is for educational purposes only.
Predictions should not be used to make important decisions about students.
